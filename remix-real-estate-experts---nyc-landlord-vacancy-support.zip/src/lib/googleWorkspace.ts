import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { VacancyFormData, LeadRecord } from '../types';

// Initialize Firebase App if not already initialized
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
// Request all authorized Google Workspace scopes
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/documents');
provider.addScope('https://www.googleapis.com/auth/calendar');
provider.addScope('https://www.googleapis.com/auth/contacts');
provider.addScope('https://www.googleapis.com/auth/drive.file');

let isSigningIn = false;
let cachedAccessToken: string | null = null;

export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get Google access token. Please verify workspace permissions.');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Workspace Sign-in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = (): string | null => {
  return cachedAccessToken;
};

export const googleSignOut = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

// =========================================================================
// 1. GOOGLE SHEETS API
// =========================================================================

export interface GoogleSpreadsheet {
  spreadsheetId: string;
  spreadsheetUrl: string;
  title: string;
}

export const createVacanciesSpreadsheet = async (
  accessToken: string,
  title: string = 'NYC Vacancies & Landlord Leads Tracker - Joy Chowdhury KW'
): Promise<GoogleSpreadsheet> => {
  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: { title },
      sheets: [
        {
          properties: {
            title: 'Vacancies & Leads',
            gridProperties: { frozenRowCount: 1 }
          },
          data: [
            {
              startRow: 0,
              startColumn: 0,
              rowData: [
                {
                  values: [
                    'ID',
                    'Date Submitted',
                    'Landlord/Manager Name',
                    'Role',
                    'Phone',
                    'Email',
                    'Borough',
                    'Address',
                    'Unit Count',
                    'Bedrooms',
                    'Asking Rent ($)',
                    'Availability',
                    'Pipeline Stage',
                    'Assigned Agent',
                    'Notes'
                  ].map(val => ({
                    userEnteredValue: { stringValue: val },
                    userEnteredFormat: {
                      textFormat: { bold: true },
                      backgroundColor: { red: 0.05, green: 0.15, blue: 0.25 }
                    }
                  }))
                }
              ]
            }
          ]
        }
      ]
    })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Failed to create Google Sheet');
  }

  const data = await response.json();
  return {
    spreadsheetId: data.spreadsheetId,
    spreadsheetUrl: data.spreadsheetUrl,
    title: data.properties.title
  };
};

export const appendLeadToSheet = async (
  spreadsheetId: string,
  accessToken: string,
  lead: VacancyFormData | LeadRecord
): Promise<boolean> => {
  const rowValues = [
    ('id' in lead ? lead.id : `INTAKE-${Date.now().toString().slice(-6)}`),
    new Date().toLocaleDateString('en-US'),
    lead.fullName || 'N/A',
    ('role' in lead ? lead.role : 'Landlord'),
    lead.mobilePhone || 'N/A',
    lead.email || 'N/A',
    lead.borough || 'N/A',
    ('propertyAddress' in lead ? lead.propertyAddress : 'Unspecified'),
    ('unitCount' in lead ? lead.unitCount : '1'),
    lead.bedroomCount || 'N/A',
    lead.askingRent || 'N/A',
    lead.availability || 'Available Now',
    ('pipelineStage' in lead ? lead.pipelineStage : 'New Vacancy Intake'),
    ('assignedTo' in lead ? lead.assignedTo : 'Joy Chowdhury'),
    ('mainQuestion' in lead ? lead.mainQuestion : ('additionalInfo' in lead ? lead.additionalInfo : 'NYC Landlord Vacancy Inquiry'))
  ];

  const range = 'Vacancies & Leads!A:O';
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: [rowValues] })
    }
  );

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Failed to append row to Google Sheet');
  }

  return true;
};

export const getSheetData = async (
  spreadsheetId: string,
  accessToken: string
): Promise<string[][]> => {
  const range = 'Vacancies & Leads!A1:O100';
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`,
    {
      headers: { 'Authorization': `Bearer ${accessToken}` }
    }
  );

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Failed to fetch Google Sheet rows');
  }

  const data = await response.json();
  return data.values || [];
};

// =========================================================================
// 2. GOOGLE DOCS API
// =========================================================================

export interface GoogleDocument {
  documentId: string;
  documentUrl: string;
  title: string;
}

export const createLandlordDoc = async (
  accessToken: string,
  lead: VacancyFormData | LeadRecord
): Promise<GoogleDocument> => {
  const name = lead.fullName || 'NYC Landlord Client';
  const borough = lead.borough || 'Queens';
  const title = `NYC HRA & Landlord Placement Agreement - ${name} (${borough})`;

  // 1. Create blank doc
  const res = await fetch('https://docs.googleapis.com/v1/documents', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ title })
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error?.message || 'Failed to create Google Doc');
  }

  const doc = await res.json();
  const documentId = doc.documentId;
  const documentUrl = `https://docs.google.com/document/d/${documentId}/edit`;

  // 2. Populate text in document
  const contentText = 
    `NYC LANDLORD VACANCY & HRA VOUCHER PLACEMENT AGREEMENT\n` +
    `Keller Williams Realty Landmark II — Specialist: Joy Chowdhury\n\n` +
    `================================================================\n` +
    `1. LANDLORD & PROPERTY DETAILS\n` +
    `• Full Name / Entity: ${name}\n` +
    `• Role: ${'role' in lead ? lead.role : 'Landlord / Owner'}\n` +
    `• Phone: ${lead.mobilePhone || 'N/A'}\n` +
    `• Email: ${lead.email || 'N/A'}\n` +
    `• Property Address: ${'propertyAddress' in lead ? lead.propertyAddress : 'Unspecified'}\n` +
    `• Borough: ${borough}\n` +
    `• Unit Count: ${'unitCount' in lead ? lead.unitCount : '1'}\n` +
    `• Bedroom Count: ${lead.bedroomCount || 'N/A'}\n` +
    `• Asking Rent: $${lead.askingRent || 'N/A'}/month\n` +
    `• Date Generated: ${new Date().toLocaleDateString()}\n\n` +
    `================================================================\n` +
    `2. PROGRAM ELIGIBILITY & INCENTIVE SUMMARY\n` +
    `• CityFHEPS / Section 8 Coverage: Guaranteed monthly direct deposit payments via NYC HRA / NYCHA.\n` +
    `• Landlord Sign-on Incentive: Eligible for up to 15% upfront cash sign-on bonus ($3,500+ depending on unit size).\n` +
    `• Unit Repair Fund: Access to up to $1,000 for required minor repairs during HQS pre-inspection.\n` +
    `• Broker Fee: 100% paid directly by NYC HRA — ZERO cost to landlord.\n\n` +
    `================================================================\n` +
    `3. HQS PRE-INSPECTION PREPARATION CHECKLIST\n` +
    `[ ] Working smoke & carbon monoxide detectors on each level.\n` +
    `[ ] Double-keyed deadbolts replaced with thumb-turn locks (NYC fire code).\n` +
    `[ ] Window guards installed in units with children under 10 years old.\n` +
    `[ ] Operable hot & cold water running at proper pressure.\n` +
    `[ ] Self-closing apartment entry door.\n\n` +
    `================================================================\n` +
    `4. EXCLUSIVE BROKERAGE REPRESENTATION\n` +
    `Licensed Real Estate Salesperson: Joy Chowdhury\n` +
    `Keller Williams Realty Landmark II\n` +
    `Office Address: 75-35 31st Ave, Suite 202, Jackson Heights, NY 11370\n` +
    `Direct Cell: (917) 565-4788 | Email: nyjoy@kw.com\n`;

  const batchRes = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      requests: [
        {
          insertText: {
            location: { index: 1 },
            text: contentText
          }
        }
      ]
    })
  });

  if (!batchRes.ok) {
    const err = await batchRes.json();
    throw new Error(err.error?.message || 'Failed to populate Google Doc content');
  }

  return { documentId, documentUrl, title };
};

// =========================================================================
// 3. GOOGLE CALENDAR API
// =========================================================================

export interface CalendarEventData {
  summary: string;
  description: string;
  location?: string;
  startIso: string;
  endIso: string;
  attendeeEmail?: string;
}

export const createCalendarEvent = async (
  accessToken: string,
  event: CalendarEventData
): Promise<{ eventId: string; htmlLink: string }> => {
  const payload: any = {
    summary: event.summary,
    location: event.location || 'KW Realty Landmark II, 75-35 31st Ave Suite 202, Jackson Heights, NY 11370',
    description: event.description,
    start: { dateTime: event.startIso, timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone },
    end: { dateTime: event.endIso, timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone },
    reminders: {
      useDefault: false,
      overrides: [
        { method: 'email', minutes: 24 * 60 },
        { method: 'popup', minutes: 30 }
      ]
    }
  };

  if (event.attendeeEmail) {
    payload.attendees = [{ email: event.attendeeEmail }];
  }

  const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?sendUpdates=all', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error?.message || 'Failed to create event on Google Calendar');
  }

  const data = await res.json();
  return {
    eventId: data.id,
    htmlLink: data.htmlLink
  };
};

// =========================================================================
// 4. GOOGLE CONTACTS (PEOPLE API)
// =========================================================================

export interface ContactData {
  givenName: string;
  familyName?: string;
  email?: string;
  phoneNumber?: string;
  address?: string;
  notes?: string;
}

export const createGoogleContact = async (
  accessToken: string,
  contact: ContactData
): Promise<{ resourceName: string; name: string }> => {
  const payload: any = {
    names: [
      {
        givenName: contact.givenName,
        familyName: contact.familyName || ''
      }
    ],
    organizations: [
      {
        name: 'NYC Landlord / Property Owner',
        title: 'KW Realty Landmark II Placement Client'
      }
    ]
  };

  if (contact.email) {
    payload.emailAddresses = [{ value: contact.email, type: 'work' }];
  }

  if (contact.phoneNumber) {
    payload.phoneNumbers = [{ value: contact.phoneNumber, type: 'mobile' }];
  }

  if (contact.address) {
    payload.addresses = [{ formattedValue: contact.address, type: 'home' }];
  }

  if (contact.notes) {
    payload.biographies = [{ value: contact.notes, contentType: 'TEXT_PLAIN' }];
  }

  const res = await fetch('https://people.googleapis.com/v1/people:createContact', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error?.message || 'Failed to save contact in Google Contacts');
  }

  const data = await res.json();
  const primaryName = data.names?.[0]?.displayName || `${contact.givenName} ${contact.familyName || ''}`.trim();

  return {
    resourceName: data.resourceName,
    name: primaryName
  };
};
