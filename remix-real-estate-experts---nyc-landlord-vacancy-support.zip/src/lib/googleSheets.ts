import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';
import { VacancyFormData, LeadRecord } from '../types';

// Initialize Firebase App if not already initialized
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
const auth = getAuth(app);

const provider = new GoogleAuthProvider();
provider.addScope('https://www.googleapis.com/auth/spreadsheets');
provider.addScope('https://www.googleapis.com/auth/drive.file');

let isSigningIn = false;
let cachedAccessToken: string | null = null;

export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error('Failed to get Google access token. Please verify permissions.');
    }

    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error: any) {
    console.error('Google Sign-in error:', error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

export const getAccessToken = (): string | null => {
  return cachedAccessToken;
};

export const googleSignOut = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

// -------------------------------------------------------------------------
// Google Sheets REST API Operations
// -------------------------------------------------------------------------

export interface GoogleSpreadsheet {
  spreadsheetId: string;
  spreadsheetUrl: string;
  title: string;
}

export const createVacanciesSpreadsheet = async (
  accessToken: string,
  title: string = 'NYC Vacancies & Landlord Leads Tracker - Joy Chowdhury KW'
): Promise<GoogleSpreadsheet> => {
  const response = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      properties: {
        title: title
      },
      sheets: [
        {
          properties: {
            title: 'Vacancies & Leads',
            gridProperties: {
              frozenRowCount: 1
            }
          },
          data: [
            {
              startRow: 0,
              startColumn: 0,
              rowData: [
                {
                  values: [
                    'ID',
                    'Date Submitted',
                    'Landlord/Manager Name',
                    'Role',
                    'Phone',
                    'Email',
                    'Borough',
                    'Address',
                    'Unit Count',
                    'Bedrooms',
                    'Asking Rent ($)',
                    'Availability',
                    'Pipeline Stage',
                    'Assigned Agent',
                    'Notes'
                  ].map(val => ({
                    userEnteredValue: { stringValue: val },
                    userEnteredFormat: {
                      textFormat: { bold: true },
                      backgroundColor: { red: 0.05, green: 0.15, blue: 0.25 }
                    }
                  }))
                }
              ]
            }
          ]
        }
      ]
    })
  });

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Failed to create Google Sheet');
  }

  const data = await response.json();
  return {
    spreadsheetId: data.spreadsheetId,
    spreadsheetUrl: data.spreadsheetUrl,
    title: data.properties.title
  };
};

export const appendLeadToSheet = async (
  spreadsheetId: string,
  accessToken: string,
  lead: VacancyFormData | LeadRecord
): Promise<boolean> => {
  const isForm = 'fullName' in lead && 'mobilePhone' in lead;
  
  const rowValues = [
    ('id' in lead ? lead.id : `INTAKE-${Date.now().toString().slice(-6)}`),
    new Date().toLocaleDateString('en-US'),
    lead.fullName || 'N/A',
    ('role' in lead ? lead.role : 'Landlord'),
    lead.mobilePhone || 'N/A',
    lead.email || 'N/A',
    lead.borough || 'N/A',
    ('propertyAddress' in lead ? lead.propertyAddress : 'Unspecified'),
    ('unitCount' in lead ? lead.unitCount : '1'),
    lead.bedroomCount || 'N/A',
    lead.askingRent || 'N/A',
    lead.availability || 'Available Now',
    ('pipelineStage' in lead ? lead.pipelineStage : 'New Vacancy Intake'),
    ('assignedTo' in lead ? lead.assignedTo : 'Joy Chowdhury'),
    ('mainQuestion' in lead ? lead.mainQuestion : ('additionalInfo' in lead ? lead.additionalInfo : 'NYC Landlord Vacancy Placement Inquiry'))
  ];

  const range = 'Vacancies & Leads!A:O';
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        values: [rowValues]
      })
    }
  );

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Failed to append row to Google Sheet');
  }

  return true;
};

export const getSheetData = async (
  spreadsheetId: string,
  accessToken: string
): Promise<string[][]> => {
  const range = 'Vacancies & Leads!A1:O100';
  const response = await fetch(
    `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`,
    {
      headers: {
        'Authorization': `Bearer ${accessToken}`
      }
    }
  );

  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error?.message || 'Failed to fetch Google Sheet rows');
  }

  const data = await response.json();
  return data.values || [];
};
