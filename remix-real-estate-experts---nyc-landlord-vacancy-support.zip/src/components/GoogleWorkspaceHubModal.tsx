import React, { useState, useEffect } from 'react';
import { X, FileSpreadsheet, FileText, Calendar, Users, CheckCircle2, AlertCircle, ExternalLink, RefreshCw, Plus, Download, LogOut, ShieldCheck, Clock, UserPlus } from 'lucide-react';
import { 
  googleSignIn, 
  googleSignOut, 
  initAuth, 
  createVacanciesSpreadsheet, 
  appendLeadToSheet, 
  getSheetData,
  createLandlordDoc,
  createCalendarEvent,
  createGoogleContact,
  GoogleSpreadsheet
} from '../lib/googleWorkspace';
import { LeadRecord, VacancyFormData } from '../types';

interface GoogleWorkspaceHubModalProps {
  isOpen: boolean;
  onClose: () => void;
  leads?: LeadRecord[];
  activeLead?: VacancyFormData | LeadRecord | null;
}

export const GoogleWorkspaceHubModal: React.FC<GoogleWorkspaceHubModalProps> = ({
  isOpen,
  onClose,
  leads = [],
  activeLead = null
}) => {
  const [activeTab, setActiveTab] = useState<'sheets' | 'docs' | 'calendar' | 'contacts'>('sheets');
  const [user, setUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);

  // Sheets State
  const [spreadsheetId, setSpreadsheetId] = useState<string | null>(
    localStorage.getItem('joy_kw_google_sheet_id') || null
  );
  const [spreadsheetUrl, setSpreadsheetUrl] = useState<string | null>(
    localStorage.getItem('joy_kw_google_sheet_url') || null
  );
  const [sheetRows, setSheetRows] = useState<string[][]>([]);

  // Docs State
  const [generatedDocs, setGeneratedDocs] = useState<Array<{ title: string; url: string; id: string }>>([]);

  // Calendar Form State
  const [eventSummary, setEventSummary] = useState('1-on-1 NYC Landlord Consultation - Joy Chowdhury (KW Landmark II)');
  const [eventDate, setEventDate] = useState(new Date().toISOString().split('T')[0]);
  const [eventTime, setEventTime] = useState('14:00');
  const [eventEmail, setEventEmail] = useState('');
  const [createdEvents, setCreatedEvents] = useState<Array<{ summary: string; link: string; date: string }>>([]);

  // Contacts Form State
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactBorough, setContactBorough] = useState('Queens');
  const [createdContacts, setCreatedContacts] = useState<Array<{ name: string; resource: string }>>([]);

  // Global UX State
  const [isLoading, setIsLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const unsubscribe = initAuth(
      (authUser, token) => {
        setUser(authUser);
        setAccessToken(token);
      },
      () => {
        setUser(null);
        setAccessToken(null);
      }
    );

    return () => unsubscribe();
  }, [isOpen]);

  useEffect(() => {
    if (activeLead) {
      if ('fullName' in activeLead && activeLead.fullName) {
        setContactName(activeLead.fullName);
        const nameParts = activeLead.fullName.split(' ');
        setEventSummary(`Landlord Consultation: Joy Chowdhury & ${activeLead.fullName}`);
      }
      if ('email' in activeLead && activeLead.email) {
        setEventEmail(activeLead.email);
        setContactEmail(activeLead.email);
      }
      if ('mobilePhone' in activeLead && activeLead.mobilePhone) {
        setContactPhone(activeLead.mobilePhone);
      }
      if ('borough' in activeLead && activeLead.borough) {
        setContactBorough(activeLead.borough);
      }
    }
  }, [activeLead]);

  useEffect(() => {
    if (accessToken && spreadsheetId && activeTab === 'sheets') {
      loadSheetPreview(spreadsheetId, accessToken);
    }
  }, [accessToken, spreadsheetId, activeTab]);

  const handleSignIn = async () => {
    setIsSigningIn(true);
    setErrorMsg(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setAccessToken(res.accessToken);
        setStatusMessage(`Workspace Authorized as ${res.user.email}`);
      }
    } catch (err: any) {
      console.error('Google Auth Error:', err);
      setErrorMsg(err.message || 'Failed to authorize Google Workspace permissions.');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await googleSignOut();
    setUser(null);
    setAccessToken(null);
    setStatusMessage('Signed out of Google Workspace.');
  };

  // --- 1. SHEETS HANDLERS ---
  const handleCreateNewSheet = async () => {
    if (!accessToken) return;
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const sheet = await createVacanciesSpreadsheet(accessToken);
      setSpreadsheetId(sheet.spreadsheetId);
      setSpreadsheetUrl(sheet.spreadsheetUrl);
      localStorage.setItem('joy_kw_google_sheet_id', sheet.spreadsheetId);
      localStorage.setItem('joy_kw_google_sheet_url', sheet.spreadsheetUrl);
      setStatusMessage(`Created Google Sheet: "${sheet.title}"`);
      await loadSheetPreview(sheet.spreadsheetId, accessToken);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create Google Sheet');
    } fontally: { setIsLoading(false); }
  };

  const loadSheetPreview = async (id: string, token: string) => {
    try {
      const rows = await getSheetData(id, token);
      setSheetRows(rows);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to load sheet data');
    }
  };

  const handleSyncAllLeads = async () => {
    if (!accessToken || !spreadsheetId) return;
    setIsLoading(true);
    setErrorMsg(null);
    try {
      let count = 0;
      for (const lead of leads) {
        await appendLeadToSheet(spreadsheetId, accessToken, lead);
        count++;
      }
      setStatusMessage(`Exported ${count} CRM leads to Google Sheets!`);
      await loadSheetPreview(spreadsheetId, accessToken);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to export leads');
    } finally {
      setIsLoading(false);
    }
  };

  // --- 2. DOCS HANDLERS ---
  const handleGenerateDoc = async () => {
    if (!accessToken) return;
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const targetData = activeLead || (leads.length > 0 ? leads[0] : {
        fullName: 'Joy Chowdhury Client',
        borough: 'Queens',
        mobilePhone: '917-565-4788',
        email: 'nyjoy@kw.com',
        askingRent: '2500',
        bedroomCount: '2 Beds'
      });

      const doc = await createLandlordDoc(accessToken, targetData as any);
      setGeneratedDocs(prev => [{ title: doc.title, url: doc.documentUrl, id: doc.documentId }, ...prev]);
      setStatusMessage(`Generated Google Doc: "${doc.title}"`);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to generate Google Doc');
    } finally {
      setIsLoading(false);
    }
  };

  // --- 3. CALENDAR HANDLERS ---
  const handleScheduleCalendarEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken) return;
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const startDateTime = `${eventDate}T${eventTime}:00`;
      const endDateObj = new Date(startDateTime);
      endDateObj.setHours(endDateObj.getHours() + 1);
      const endDateTime = endDateObj.toISOString().split('.')[0];

      const res = await createCalendarEvent(accessToken, {
        summary: eventSummary,
        description: `1-on-1 NYC Landlord & Voucher Placement Consultation with Joy Chowdhury (KW Realty Landmark II).\nContact Email: ${eventEmail || 'nyjoy@kw.com'}`,
        startIso: startDateTime,
        endIso: endDateTime,
        attendeeEmail: eventEmail || undefined
      });

      setCreatedEvents(prev => [{ summary: eventSummary, link: res.htmlLink, date: eventDate }, ...prev]);
      setStatusMessage(`Calendar event created successfully! SMS & Email notifications dispatched.`);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create event on Google Calendar');
    } finally {
      setIsLoading(false);
    }
  };

  // --- 4. CONTACTS HANDLERS ---
  const handleCreateContact = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessToken) return;
    setIsLoading(true);
    setErrorMsg(null);
    try {
      const parts = contactName.trim().split(' ');
      const givenName = parts[0] || 'Landlord';
      const familyName = parts.slice(1).join(' ') || '';

      const contact = await createGoogleContact(accessToken, {
        givenName,
        familyName,
        email: contactEmail,
        phoneNumber: contactPhone,
        address: `${contactBorough}, New York City, NY`,
        notes: `NYC Landlord / Property Manager Lead processed by Joy Chowdhury (KW Realty Landmark II). Borough: ${contactBorough}`
      });

      setCreatedContacts(prev => [{ name: contact.name, resource: contact.resourceName }, ...prev]);
      setStatusMessage(`Saved contact "${contact.name}" into your Google Contacts!`);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to create Google Contact');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-teal-500/30 rounded-3xl w-full max-w-3xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        
        {/* Modal Top Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-400 border border-teal-500/30 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white font-serif">Google Workspace Integration Hub</h3>
              <p className="text-xs text-slate-400 font-sans">Google Sheets, Docs, Calendar, and Contacts for Joy Chowdhury (KW Landmark II)</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Workspace Scopes Tab Navigation */}
        <div className="bg-slate-950/60 px-6 pt-2 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
          <button
            onClick={() => setActiveTab('sheets')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold transition-colors border-t border-x ${
              activeTab === 'sheets'
                ? 'bg-slate-900 text-emerald-400 border-slate-800 border-b-slate-900'
                : 'text-slate-400 hover:text-white border-transparent'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Google Sheets</span>
          </button>

          <button
            onClick={() => setActiveTab('docs')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold transition-colors border-t border-x ${
              activeTab === 'docs'
                ? 'bg-slate-900 text-blue-400 border-slate-800 border-b-slate-900'
                : 'text-slate-400 hover:text-white border-transparent'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>Google Docs</span>
          </button>

          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold transition-colors border-t border-x ${
              activeTab === 'calendar'
                ? 'bg-slate-900 text-purple-400 border-slate-800 border-b-slate-900'
                : 'text-slate-400 hover:text-white border-transparent'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>Google Calendar</span>
          </button>

          <button
            onClick={() => setActiveTab('contacts')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl text-xs font-bold transition-colors border-t border-x ${
              activeTab === 'contacts'
                ? 'bg-slate-900 text-teal-400 border-slate-800 border-b-slate-900'
                : 'text-slate-400 hover:text-white border-transparent'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Google Contacts</span>
          </button>
        </div>

        {/* Main Content Area */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm text-slate-300">
          
          {errorMsg && (
            <div className="bg-red-950/80 border border-red-800 text-red-200 text-xs p-3.5 rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {statusMessage && (
            <div className="bg-emerald-950/80 border border-emerald-800 text-emerald-200 text-xs p-3.5 rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {/* Account Authentication Banner */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Google Workspace Authorization</span>
              {user ? (
                <span className="text-[11px] bg-emerald-950 text-emerald-400 px-2.5 py-0.5 rounded border border-emerald-800 font-medium">
                  Authorized
                </span>
              ) : (
                <span className="text-[11px] bg-yellow-950 text-yellow-300 px-2.5 py-0.5 rounded border border-yellow-800 font-medium">
                  Requires Workspace Login
                </span>
              )}
            </div>

            {!user ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-400">
                  Click below to authorize Google Workspace scopes (Sheets, Docs, Calendar, and Contacts) for real-time NYC landlord vacancy automation.
                </p>
                <button
                  type="button"
                  onClick={handleSignIn}
                  disabled={isSigningIn}
                  className="w-full flex items-center justify-center gap-3 bg-white text-slate-900 hover:bg-slate-100 font-semibold px-4 py-3 rounded-xl transition-all shadow-md cursor-pointer disabled:opacity-50 text-xs sm:text-sm"
                >
                  <svg className="w-5 h-5" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                  </svg>
                  <span>{isSigningIn ? 'Authorizing Workspace...' : 'Authorize Google Workspace APIs'}</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between text-xs bg-slate-900 p-3 rounded-xl border border-slate-800">
                <div>
                  <div className="font-semibold text-white">{user.displayName || 'Google Account'}</div>
                  <div className="text-slate-400">{user.email}</div>
                </div>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-1 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </div>

          {/* TAB 1: GOOGLE SHEETS */}
          {activeTab === 'sheets' && (
            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">Master Vacancy Tracker</span>

                {spreadsheetId ? (
                  <div className="space-y-3">
                    <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                      <div>
                        <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                          <FileSpreadsheet className="w-4 h-4" />
                          <span>NYC Vacancies & Landlord Leads Tracker</span>
                        </div>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">ID: {spreadsheetId}</div>
                      </div>

                      {spreadsheetUrl && (
                        <a
                          href={spreadsheetUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 transition-colors border border-emerald-500/30"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>Open Sheet</span>
                        </a>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={handleSyncAllLeads}
                        disabled={isLoading || leads.length === 0}
                        className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-slate-900 bg-emerald-400 hover:bg-emerald-300 transition-colors cursor-pointer disabled:opacity-50"
                      >
                        <Download className="w-4 h-4" />
                        <span>{isLoading ? 'Exporting...' : `Export ${leads.length} Leads to Google Sheet`}</span>
                      </button>

                      <button
                        onClick={() => accessToken && loadSheetPreview(spreadsheetId, accessToken)}
                        className="p-2.5 bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800 rounded-xl transition-colors cursor-pointer"
                        title="Refresh Sheet Preview"
                      >
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <p className="text-xs text-slate-400">
                      No Google Sheet initialized yet. Click below to create a formatted master vacancy sheet in your Google Drive.
                    </p>
                    <button
                      onClick={handleCreateNewSheet}
                      disabled={isLoading || !user}
                      className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <Plus className="w-4 h-4" />
                      <span>{isLoading ? 'Creating Sheet...' : 'Create Master Vacancies Sheet'}</span>
                    </button>
                  </div>
                )}
              </div>

              {sheetRows.length > 0 && (
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">Live Sheet Row Preview</span>
                    <span className="text-[10px] text-slate-400 font-mono">{sheetRows.length} Rows</span>
                  </div>
                  <div className="overflow-x-auto border border-slate-800 rounded-xl">
                    <table className="w-full text-left text-[11px]">
                      <thead>
                        <tr className="bg-slate-900 text-emerald-300 font-mono border-b border-slate-800">
                          {sheetRows[0]?.slice(0, 6).map((header, idx) => (
                            <th key={idx} className="p-2 whitespace-nowrap">{header}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-800/60 font-sans">
                        {sheetRows.slice(1, 6).map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-slate-900/50">
                            {row.slice(0, 6).map((cell, cIdx) => (
                              <td key={cIdx} className="p-2 whitespace-nowrap text-slate-300">{cell}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: GOOGLE DOCS */}
          {activeTab === 'docs' && (
            <div className="space-y-4">
              <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-blue-400">NYC Landlord Agreement & HRA Packet Generator</span>
                <p className="text-xs text-slate-400">
                  Automatically build formatted Google Documents in Google Drive containing NYC landlord intake details, HRA 15% bonus agreements, and HQS preparation checklists.
                </p>

                <button
                  onClick={handleGenerateDoc}
                  disabled={isLoading || !user}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <FileText className="w-4 h-4" />
                  <span>{isLoading ? 'Generating Google Doc...' : 'Generate NYC Landlord Packet in Google Docs'}</span>
                </button>
              </div>

              {generatedDocs.length > 0 && (
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-blue-400">Generated Google Documents ({generatedDocs.length})</span>
                  <div className="space-y-2">
                    {generatedDocs.map((doc, idx) => (
                      <div key={idx} className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2 text-blue-300 font-medium truncate">
                          <FileText className="w-4 h-4 flex-shrink-0" />
                          <span className="truncate">{doc.title}</span>
                        </div>
                        <a
                          href={doc.url}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 font-semibold transition-colors flex-shrink-0 ml-2"
                        >
                          <span>Open Doc</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: GOOGLE CALENDAR */}
          {activeTab === 'calendar' && (
            <div className="space-y-4">
              <form onSubmit={handleScheduleCalendarEvent} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-purple-400">Schedule Consultation on Google Calendar</span>
                
                <div className="space-y-2">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400">Event Title</label>
                    <input
                      type="text"
                      value={eventSummary}
                      onChange={e => setEventSummary(e.target.value)}
                      required
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-400">Date</label>
                      <input
                        type="date"
                        value={eventDate}
                        onChange={e => setEventDate(e.target.value)}
                        required
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-400">Time</label>
                      <input
                        type="time"
                        value={eventTime}
                        onChange={e => setEventTime(e.target.value)}
                        required
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-400">Client Email (Invite Attendee)</label>
                    <input
                      type="email"
                      value={eventEmail}
                      onChange={e => setEventEmail(e.target.value)}
                      placeholder="landlord@example.com"
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !user}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs font-bold text-white bg-purple-600 hover:bg-purple-500 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <Calendar className="w-4 h-4" />
                  <span>{isLoading ? 'Booking Event...' : 'Schedule Event on Google Calendar'}</span>
                </button>
              </form>

              {createdEvents.length > 0 && (
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-purple-400">Booked Calendar Events ({createdEvents.length})</span>
                  <div className="space-y-2">
                    {createdEvents.map((ev, idx) => (
                      <div key={idx} className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                        <div>
                          <div className="text-purple-300 font-semibold">{ev.summary}</div>
                          <div className="text-slate-400 text-[11px]">{ev.date}</div>
                        </div>
                        <a
                          href={ev.link}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-xs text-purple-400 hover:text-purple-300 font-semibold"
                        >
                          <span>Google Calendar</span>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: GOOGLE CONTACTS */}
          {activeTab === 'contacts' && (
            <div className="space-y-4">
              <form onSubmit={handleCreateContact} className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Save Landlord to Google Contacts</span>
                
                <div className="space-y-2">
                  <div>
                    <label className="text-[11px] font-semibold text-slate-400">Landlord / Owner Name</label>
                    <input
                      type="text"
                      value={contactName}
                      onChange={e => setContactName(e.target.value)}
                      placeholder="e.g. Joy Chowdhury"
                      required
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-[11px] font-semibold text-slate-400">Mobile Phone</label>
                      <input
                        type="tel"
                        value={contactPhone}
                        onChange={e => setContactPhone(e.target.value)}
                        placeholder="917-565-4788"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-semibold text-slate-400">Email Address</label>
                      <input
                        type="email"
                        value={contactEmail}
                        onChange={e => setContactEmail(e.target.value)}
                        placeholder="landlord@example.com"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-semibold text-slate-400">NYC Borough Location</label>
                    <select
                      value={contactBorough}
                      onChange={e => setContactBorough(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-teal-500"
                    >
                      <option value="Queens">Queens</option>
                      <option value="Brooklyn">Brooklyn</option>
                      <option value="Bronx">Bronx</option>
                      <option value="Manhattan">Manhattan</option>
                      <option value="Staten Island">Staten Island</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !user}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs font-bold text-slate-900 bg-teal-400 hover:bg-teal-300 transition-colors cursor-pointer disabled:opacity-50"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{isLoading ? 'Saving Contact...' : 'Save to Google Contacts'}</span>
                </button>
              </form>

              {createdContacts.length > 0 && (
                <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Saved Contacts ({createdContacts.length})</span>
                  <div className="space-y-2">
                    {createdContacts.map((c, idx) => (
                      <div key={idx} className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
                        <div className="text-emerald-400 font-medium flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>{c.name}</span>
                        </div>
                        <span className="text-[11px] text-slate-400 font-mono">Saved in People API</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Modal Bottom Status Bar */}
        <div className="bg-slate-950 px-6 py-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>Google Workspace APIs Connected</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
