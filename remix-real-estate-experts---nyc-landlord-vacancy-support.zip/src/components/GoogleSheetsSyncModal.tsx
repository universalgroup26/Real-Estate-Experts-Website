import React, { useState, useEffect } from 'react';
import { X, FileSpreadsheet, CheckCircle2, AlertCircle, ExternalLink, RefreshCw, Plus, Download, LogOut } from 'lucide-react';
import { googleSignIn, googleSignOut, createVacanciesSpreadsheet, appendLeadToSheet, getSheetData, initAuth } from '../lib/googleSheets';
import { LeadRecord } from '../types';

interface GoogleSheetsSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
  leads?: LeadRecord[];
}

export const GoogleSheetsSyncModal: React.FC<GoogleSheetsSyncModalProps> = ({
  isOpen,
  onClose,
  leads = []
}) => {
  const [user, setUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isSigningIn, setIsSigningIn] = useState(false);
  const [spreadsheetId, setSpreadsheetId] = useState<string | null>(
    localStorage.getItem('joy_kw_google_sheet_id') || null
  );
  const [spreadsheetUrl, setSpreadsheetUrl] = useState<string | null>(
    localStorage.getItem('joy_kw_google_sheet_url') || null
  );
  const [sheetRows, setSheetRows] = useState<string[][]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const unsubscribe = initAuth(
      (authUser, token) => {
        setUser(authUser);
        setAccessToken(token);
      },
      () => {
        setUser(null);
        setAccessToken(null);
      }
    );

    return () => unsubscribe();
  }, [isOpen]);

  useEffect(() => {
    if (accessToken && spreadsheetId) {
      loadSheetPreview(spreadsheetId, accessToken);
    }
  }, [accessToken, spreadsheetId]);

  const handleSignIn = async () => {
    setIsSigningIn(true);
    setErrorMsg(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setAccessToken(res.accessToken);
        setStatusMessage(`Signed in as ${res.user.email}`);
      }
    } catch (err: any) {
      console.error('Google Auth Error:', err);
      setErrorMsg(err.message || 'Failed to sign in with Google');
    } finally {
      setIsSigningIn(false);
    }
  };

  const handleSignOut = async () => {
    await googleSignOut();
    setUser(null);
    setAccessToken(null);
    setStatusMessage('Signed out successfully.');
  };

  const handleCreateNewSheet = async () => {
    if (!accessToken) {
      setErrorMsg('Please sign in with Google first.');
      return;
    }

    setIsLoading(true);
    setErrorMsg(null);
    try {
      const sheet = await createVacanciesSpreadsheet(accessToken);
      setSpreadsheetId(sheet.spreadsheetId);
      setSpreadsheetUrl(sheet.spreadsheetUrl);
      localStorage.setItem('joy_kw_google_sheet_id', sheet.spreadsheetId);
      localStorage.setItem('joy_kw_google_sheet_url', sheet.spreadsheetUrl);
      setStatusMessage(`Created new Google Sheet: "${sheet.title}"`);
      await loadSheetPreview(sheet.spreadsheetId, accessToken);
    } catch (err: any) {
      console.error('Create Sheet Error:', err);
      setErrorMsg(err.message || 'Failed to create Google Sheet');
    } finally {
      setIsLoading(false);
    }
  };

  const loadSheetPreview = async (id: string, token: string) => {
    try {
      const rows = await getSheetData(id, token);
      setSheetRows(rows);
    } catch (err: any) {
      console.error('Load Sheet Rows Error:', err);
      setErrorMsg(err.message || 'Failed to load sheet data');
    }
  };

  const handleSyncAllLeads = async () => {
    if (!accessToken || !spreadsheetId) {
      setErrorMsg('Please sign in and create/select a Google Sheet first.');
      return;
    }

    setIsSyncing(true);
    setErrorMsg(null);
    try {
      let count = 0;
      for (const lead of leads) {
        await appendLeadToSheet(spreadsheetId, accessToken, lead);
        count++;
      }
      setStatusMessage(`Successfully exported ${count} CRM leads to Google Sheets!`);
      await loadSheetPreview(spreadsheetId, accessToken);
    } catch (err: any) {
      console.error('Sync Error:', err);
      setErrorMsg(err.message || 'Failed to sync leads to Google Sheet');
    } finally {
      setIsSyncing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-slate-900 border border-teal-500/30 rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="bg-slate-950 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white font-serif">Google Sheets Integration</h3>
              <p className="text-xs text-slate-400 font-sans">Sync NYC Landlord Vacancies & CRM Leads directly to Google Drive</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-sm text-slate-300">
          
          {errorMsg && (
            <div className="bg-red-950/80 border border-red-800 text-red-200 text-xs p-3.5 rounded-xl flex items-center gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {statusMessage && (
            <div className="bg-emerald-950/80 border border-emerald-800 text-emerald-200 text-xs p-3.5 rounded-xl flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{statusMessage}</span>
            </div>
          )}

          {/* 1. Google Account Connection Card */}
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-400">1. Google Account Authorization</span>
              {user && (
                <span className="text-[11px] bg-emerald-950 text-emerald-400 px-2 py-0.5 rounded border border-emerald-800 font-medium">
                  Connected
                </span>
              )}
            </div>

            {!user ? (
              <div className="space-y-3">
                <p className="text-xs text-slate-400">
                  Connect your Google account to create and manage spreadsheet trackers for your NYC landlord vacancies.
                </p>
                <button
                  type="button"
                  onClick={handleSignIn}
                  disabled={isSigningIn}
                  className="w-full flex items-center justify-center gap-3 bg-white text-slate-900 hover:bg-slate-100 font-semibold px-4 py-3 rounded-xl transition-all shadow-md active:scale-98 cursor-pointer disabled:opacity-50 text-xs sm:text-sm"
                >
                  <svg className="w-5 h-5" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                  </svg>
                  <span>{isSigningIn ? 'Signing in...' : 'Sign in with Google'}</span>
                </button>
              </div>
            ) : (
              <div className="flex items-center justify-between text-xs bg-slate-900 p-3 rounded-xl border border-slate-800">
                <div>
                  <div className="font-semibold text-white">{user.displayName || 'Google User'}</div>
                  <div className="text-slate-400">{user.email}</div>
                </div>
                <button
                  onClick={handleSignOut}
                  className="flex items-center gap-1 text-slate-400 hover:text-red-400 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              </div>
            )}
          </div>

          {/* 2. Target Spreadsheet Controls */}
          {user && (
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-400">2. Google Sheet Tracker</span>

              {spreadsheetId ? (
                <div className="space-y-3">
                  <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1.5">
                        <FileSpreadsheet className="w-4 h-4" />
                        <span>NYC Vacancies & Landlord Leads Tracker</span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">ID: {spreadsheetId}</div>
                    </div>

                    {spreadsheetUrl && (
                      <a
                        href={spreadsheetUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 transition-colors border border-emerald-500/30"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Open Sheet</span>
                      </a>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleSyncAllLeads}
                      disabled={isSyncing || leads.length === 0}
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-slate-900 bg-teal-400 hover:bg-teal-300 transition-colors cursor-pointer disabled:opacity-50"
                    >
                      <Download className="w-4 h-4" />
                      <span>{isSyncing ? 'Syncing...' : `Export All Leads (${leads.length}) to Sheet`}</span>
                    </button>

                    <button
                      onClick={() => accessToken && loadSheetPreview(spreadsheetId, accessToken)}
                      className="p-2.5 bg-slate-900 text-slate-300 hover:bg-slate-800 border border-slate-800 rounded-xl transition-colors cursor-pointer"
                      title="Refresh Sheet Preview"
                    >
                      <RefreshCw className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-xs text-slate-400">
                    No spreadsheet linked yet. Click below to automatically create a master Google Sheet in your Google Drive with formatted headers.
                  </p>
                  <button
                    onClick={handleCreateNewSheet}
                    disabled={isLoading}
                    className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 transition-colors cursor-pointer disabled:opacity-50"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isLoading ? 'Creating Sheet in Drive...' : 'Create Master Vacancies Sheet in Google Drive'}</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 3. Live Sheet Preview Table */}
          {sheetRows.length > 0 && (
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-teal-400">Live Google Sheet Preview</span>
                <span className="text-[10px] text-slate-400 font-mono">{sheetRows.length} Rows</span>
              </div>

              <div className="overflow-x-auto border border-slate-800 rounded-xl">
                <table className="w-full text-left text-[11px]">
                  <thead>
                    <tr className="bg-slate-900 text-teal-300 font-mono border-b border-slate-800">
                      {sheetRows[0]?.slice(0, 6).map((header, idx) => (
                        <th key={idx} className="p-2 whitespace-nowrap">{header}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 font-sans">
                    {sheetRows.slice(1, 6).map((row, rIdx) => (
                      <tr key={rIdx} className="hover:bg-slate-900/50">
                        {row.slice(0, 6).map((cell, cIdx) => (
                          <td key={cIdx} className="p-2 whitespace-nowrap text-slate-300">{cell}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-slate-950 px-6 py-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Google Workspace OAuth Status: Active</span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-slate-300 bg-slate-800 hover:bg-slate-700 transition-colors cursor-pointer"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
